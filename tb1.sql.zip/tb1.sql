-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 04, 2020 at 09:37 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mymandal`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb1`
--

CREATE TABLE `tb1` (
  `fnum` text NOT NULL,
  `mnum` text NOT NULL,
  `lnum` text NOT NULL,
  `whatsnum` int(11) NOT NULL,
  `mobilenum` int(11) NOT NULL,
  `contry` text NOT NULL,
  `stat` text NOT NULL,
  `district1` text NOT NULL,
  `taluka1` text NOT NULL,
  `area1` text NOT NULL,
  `landmark1` varchar(120) NOT NULL,
  `email1` varchar(120) NOT NULL,
  `pass1` varchar(120) NOT NULL,
  `orgname1` varchar(120) NOT NULL,
  `googlephotolink1` varchar(120) NOT NULL,
  `facebooklink1` varchar(120) NOT NULL,
  `instalink1` varchar(120) NOT NULL,
  `youtubelink1` varchar(120) NOT NULL,
  `otherorglink1` varchar(120) NOT NULL,
  `googlemap1` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb1`
--

INSERT INTO `tb1` (`fnum`, `mnum`, `lnum`, `whatsnum`, `mobilenum`, `contry`, `stat`, `district1`, `taluka1`, `area1`, `landmark1`, `email1`, `pass1`, `orgname1`, `googlephotolink1`, `facebooklink1`, `instalink1`, `youtubelink1`, `otherorglink1`, `googlemap1`) VALUES
('SHRADDHA', 'UMESH', 'PANHALE', 2147483647, 2147483647, 'MUMBAI', 'MAHARASHTRA', 'MUMBAI', 'BORIVALI', 'KANDIVALI', 'AKURLI', 'smartworldvideo@gmail.com', 'kjfisdehg', 'etr', 'https://photos.app.goo.gl/YZsvjm47bLywuhh56', 'https://www.facebook.com/100030751541830/posts/323101872058195/?flite=scwspnss&extid=nuJJUVEODSgLEiOq', 'https://www.instagram.com/', 'https://youtu.be/wQVEst3UVx0', 'https://www.facebook.com/100030751541830/posts/323101872058195/?flite=scwspnss&extid=nuJJUVEODSgLEiOq', 'https://goo.gl/maps/ULRPvba421eMu1b4A'),
('shweta', 'UMESH', 'pawar', 784752750, 2147483647, 'pune', 'MAHARASHTRA', 'MUMBAI', 'BORIVALI', '', 'AKURLI', 'fhjwtyfikh@gmail.com', 'dkfhk', 'krf', 'https://photos.app.goo.gl/YZsvjm47bLywuhh56', 'https://www.facebook.com/100030751541830/posts/323101872058195/?flite=scwspnss&extid=nuJJUVEODSgLEiOq', 'https://www.instagram.com/', 'https://youtu.be/wQVEst3UVx0', 'https://www.facebook.com/100030751541830/posts/323101872058195/?flite=scwspnss&extid=nuJJUVEODSgLEiOq', 'https://goo.gl/maps/ULRPvba421eMu1b4A'),
('lakshmi', 'sunil', 'patil', 234454554, 887877887, 'nashik', 'MAHARASHTRA', 'nashik', 'junnar', 'kolasewadi', 'panchavati', 'hjg@gmail.com', 'ghjggjgh', 'wiva', 'https://photos.app.goo.gl/YZsvjm47bLywuhh56', 'https://www.facebook.com/100030751541830/posts/323101872058195/?flite=scwspnss&extid=nuJJUVEODSgLEiOq', 'https://www.instagram.com/', 'https://youtu.be/wQVEst3UVx0', 'https://www.facebook.com/100030751541830/posts/323101872058195/?flite=scwspnss&extid=nuJJUVEODSgLEiOq', 'https://goo.gl/maps/ULRPvba421eMu1b4A'),
('gitanjali', 'mayur', 'kale', 2147483647, 4343445, 'pune', 'MAHARASHTRA', 'pune', 'pune', 'sadashivpeth', 'ganeshroad', 'gkhkh@gmail.com', 'hhiiuuu', 'oppo', 'https://photos.app.goo.gl/YZsvjm47bLywuhh56', 'https://www.facebook.com/100030751541830/posts/323101872058195/?flite=scwspnss&extid=nuJJUVEODSgLEiOq', 'https://www.instagram.com/', 'https://youtu.be/wQVEst3UVx0', 'https://www.facebook.com/100030751541830/posts/323101872058195/?flite=scwspnss&extid=nuJJUVEODSgLEiOq', 'https://goo.gl/maps/ULRPvba421eMu1b4A'),
('rashmi', 'ganesh', 'more', 78877877, 32444445, 'MUMBAI', 'MAHARASHTRA', 'MUMBAI', 'BORIVALI', 'KANDIVALI', 'panchavati', 'hfjkh@gmail.com', 'hghhgghk', 'JJ', 'https://photos.app.goo.gl/YZsvjm47bLywuhh56', 'https://www.facebook.com/100030751541830/posts/323101872058195/?flite=scwspnss&extid=nuJJUVEODSgLEiOq', 'https://www.instagram.com/', 'https://youtu.be/wQVEst3UVx0', 'https://www.facebook.com/100030751541830/posts/323101872058195/?flite=scwspnss&extid=nuJJUVEODSgLEiOq', 'https://goo.gl/maps/ULRPvba421eMu1b4A'),
('SHRADDHA', 'UMESH', 'PANHALE', 2147483647, 2147483647, 'india', 'gujarat', 'gujrat', 'junnar', 'KANDIVALI', 'AKURLI', 'sh@gmail.com', 'b,,nkjlj', 'hjkjl', 'https://photos.app.goo.gl/YZsvjm47bLywuhh56', 'https://www.facebook.com/100030751541830/posts/323101872058195/?flite=scwspnss&extid=nuJJUVEODSgLEiOq', 'https://www.instagram.com/', 'https://youtu.be/wQVEst3UVx0', 'https://www.facebook.com/100030751541830/posts/323101872058195/?flite=scwspnss&extid=nuJJUVEODSgLEiOq', 'https://goo.gl/maps/ULRPvba421eMu1b4A'),
('mehul', 'ramesh', 'mane', 43663463, 54464343, 'in', 'MAHARASHTRA', 'MUMBAI', '', '', '', '', '', '', '', '', '', '', '', ''),
('yasuf', 'nasiir', 'khan', 483805890, 2147483647, 'india', 'MAHARASHTRA', 'MUMBAI', 'BORIVALI', 'borivali', 'koeakendra', 'dskhf@gmail.com', 'ndknf.', 'dsfhtj', ' https://photos.app.goo.gl/YZsvjm47bLywuhh56', 'https://www.facebook.com/100030751541830/posts/323101872058195/?flite=scwspnss&extid=nuJJUVEODSgLEiOq', 'https://www.instagram.com/', 'https://youtu.be/wQVEst3UVx0', 'https://www.facebook.com/100030751541830/posts/323101872058195/?flite=scwspnss&extid=nuJJUVEODSgLEiOq', 'https://goo.gl/maps/ULRPvba421eMu1b4A'),
('gopi', 'tushar', 'patil', 2147483647, 42797884, 'india', 'gujarat', 'MUMBAI', 'junnar', 'kolasewadi', 'AKURLI', 'gjh@gmail.com', 'jhbmhbj ', 'klnln', 'https://photos.app.goo.gl/YZsvjm47bLywuhh56', 'https://www.facebook.com/100030751541830/posts/323101872058195/?flite=scwspnss&extid=nuJJUVEODSgLEiOq', 'https://www.instagram.com/', 'https://youtu.be/wQVEst3UVx0', 'https://www.facebook.com/100030751541830/posts/323101872058195/?flite=scwspnss&extid=nuJJUVEODSgLEiOq', 'https://goo.gl/maps/ULRPvba421eMu1b4A'),
('usha', 'krishna', 'roy', 87787798, 2147483647, 'MUMBAI', 'gujarat', 'nashik', 'pune', 'sadashivpeth', 'ganeshroad', 'fjkdgdj@gmail.com', 'gjtjtg', 'JHKJHHK', 'https://photos.app.goo.gl/YZsvjm47bLywuhh56', 'https://www.facebook.com/100030751541830/posts/323101872058195/?flite=scwspnss&extid=nuJJUVEODSgLEiOq', 'https://www.instagram.com/', 'https://youtu.be/wQVEst3UVx0', 'https://www.facebook.com/100030751541830/posts/323101872058195/?flite=scwspnss&extid=nuJJUVEODSgLEiOq', 'https://goo.gl/maps/ULRPvba421eMu1b4A');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
